
package com.mphasis.payingguest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.payingguest.model.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking ,Integer>  {
	
}
