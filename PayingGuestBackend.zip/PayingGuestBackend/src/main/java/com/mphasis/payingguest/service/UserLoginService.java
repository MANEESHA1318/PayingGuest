package com.mphasis.payingguest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.payingguest.dao.UserLoginRepository;
import com.mphasis.payingguest.model.UserLogin;

@Service
public class UserLoginService {

	@Autowired
	UserLoginRepository userloginRepository;

	public UserLogin validateUserLogin(UserLogin userlogin) {
		UserLogin ul=userloginRepository.validateUserLogin(userlogin.getUserid(),userlogin.getPassword());
		
		return ul;
	}
	
}