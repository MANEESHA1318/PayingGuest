package com.mphasis.payingguest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="User")
public class User {
	@Id
	@GeneratedValue
	@Column(name="userid")
	private int id;
	@Column(name="username")
	
	private String username;
    @Column(name="email")
	private String email;
    @Column(name="phonenumber")
    private int phonenumber;
    @Column(name="password")
    private String password;
    @Column(name="gender")
    private String gender;
	public User(String username, String email, int phonenumber, String password, String gender) {
        super();
        this.username = username;
        this.email = email;
        this.phonenumber = phonenumber;
        this.password = password;
        this.gender = gender;
    }
	public User() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getuserid() {
		return id;
	}
	public void setId(int userid) {
		this.id = userid;
	}
	public String getusername() {
		return username;
	}
	public void setusername(String firstname) {
		this.username = username;
	}
	public String getemail() {
		return email;
	}
	public void setemail(String email) {
		this.email = email;
	}
	public int getphonenumber() {
		return phonenumber;
	}
	public void setphonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String password() {
		return password;
	}
	public void setpassword(String password) {
		this.password = password;
	}
	public String getgender() {
		return gender;
	}
	public void setgender(String gender) {
		this.gender = gender;
	}
	
	

}
