package com.mphasis.payingguest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.payingguest.exception.ResourceNotFoundException;
import com.mphasis.payingguest.model.Admin;
import com.mphasis.payingguest.service.AdminService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class AdminController {

	@Autowired
	AdminService admService;

//http://localhost:8080/api/v1/getAllAdmin
	@GetMapping("/getAllAdmin")
	public List<Admin> getAdmin() {
		List<Admin> admList = admService.fetchAdmine();

		return admList;

	}

	// http://localhost:8080/api/v1/getAdmin/1
	@GetMapping("/getAdmin/{adminPgid}")
	public ResponseEntity<Admin> getAdminByPgid(@PathVariable("adminPgid") int adminPgid)
			throws ResourceNotFoundException {
		Admin admin = admService.getAdmin(adminPgid);
		return ResponseEntity.ok().body(admin);
	}

	// http://localhost:8080/api/v1/saveAdmin
	@PostMapping("/saveAdmin")
	public Admin addAdmin(@RequestBody Admin adm) {

		Admin admin = admService.saveAdmin(adm);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return admin;
	}

	// http://localhost:8080/api/v1/updateAdmin/2
	@PutMapping("/updateAdmin/{pgid}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable("pgid") int adminPgid,
			@RequestBody Admin adminDetails) throws ResourceNotFoundException {
		Admin admin = admService.getAdmin(adminPgid);

		admin.setPgName(adminDetails.getPgName());
		admin.setPgcost(adminDetails.getPgcost());
		admin.setAvailability(adminDetails.getAvailability());
		admin.setNoofvacancies(adminDetails.getNoofvacancies());
		admin.setNoofallowcated(adminDetails.getNoofallowcated());
	
		final Admin updatedAdmin = admService.saveAdmin(admin);
		return ResponseEntity.ok(updatedAdmin);
	}

//http://localhost:8080/api/v1/deleteAdmin/1
	@DeleteMapping(value = "/deleteAdmin/{adminPgid}")
	public ResponseEntity<Object> deleteAdmin(@PathVariable("adminPgid") int admPgid) {

		admService.deleteAdmin(admPgid);
		return new ResponseEntity<>("Admin deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deleteEmployee/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int employeeId) throws
	 * ResourceNotFoundException { // Employee employee =
	 * empService.getEmployee(employeeId);
	 * 
	 * System.out.println("delete method called");
	 * empService.deleteEmployee(employeeId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}
