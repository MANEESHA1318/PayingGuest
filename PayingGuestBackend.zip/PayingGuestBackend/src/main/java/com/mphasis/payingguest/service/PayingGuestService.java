package com.mphasis.payingguest.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.payingguest.dao.PayingGuestRepository;
import com.mphasis.payingguest.model.PayingGuest;

@Service
public class PayingGuestService {

	@Autowired
	PayingGuestRepository payingguestRepository;
	
	@Transactional
	public List<PayingGuest> fetchPayingGuests() {
		List<PayingGuest> payingguestList=payingguestRepository.findAll();
		return payingguestList;
		
	}
	@Transactional
	public PayingGuest savePayingGuest(PayingGuest payingguest) {
		
		return payingguestRepository.save(payingguest);
		
	}
	@Transactional
	public void updatePayingGUest(PayingGuest payingguest) {
		payingguestRepository.save(payingguest);	
	
	}
	
	@Transactional
	public void deletePayingGuest(int pgId) {
		//pgRepository.delete(pg);	
		System.out.println("service method called");
		payingguestRepository.deleteById(pgId);
	
	}
	@Transactional 
	  public PayingGuest getPayingGuest(int id) { 
	  Optional<PayingGuest> optional= payingguestRepository.findById(id);
	  PayingGuest payingguest=optional.get();
	  return payingguest;
	  

}
}

