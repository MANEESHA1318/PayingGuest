package com.mphasis.payingguest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	@GeneratedValue
	@Column(name="pgid")
	private int pgid;
	@Column(name="pgname")
	
	private String pgName;
	@Column(name="pgcost")
	private int pgcost;
	@Column(name="availability")
	private String availability;
	@Column(name="noofvacancies")
	private int noofvacancies;

	@Column(name="noofallowcated")
	private int noofallowcated;
	public Admin(String pgname, int pgcost, String availability,int noofvacancies,int noofallowcated) {
        super();
        this.pgName = pgname;
        this.pgcost = pgcost;
        this.availability = availability;
        this.noofvacancies=noofvacancies;
        this.noofallowcated=noofallowcated;
    }
	public Admin() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getPgid() {
		return pgid;
	}
	public void setPgid(int pgid) {
		this.pgid = pgid;
	}
	public String getPgName() {
		return pgName;
	}
	public void setPgName(String pgName) {
		this.pgName = pgName;
	}
	public int getPgcost() {
		return pgcost;
	}
	public void setPgcost(int pgcost) {
		this.pgcost = pgcost;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
		
	}
	public int getNoofvacancies() {
		return noofvacancies;
	}
	public void setNoofvacancies(int noofvacancies) {
		this.noofvacancies=noofvacancies;
	}
	public int getNoofallowcated() {
		return noofallowcated;
	}
	public void setNoofallowcated(int noofallowcated) {
		this.noofallowcated=noofallowcated;
	}
	

}
