package com.mphasis.payingguest.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.payingguest.dao.UserRepository;
import com.mphasis.payingguest.model.User;


@Service
public class UserService {

	@Autowired
	UserRepository userRepository;
	
	@Transactional
	public List<User> fetchUser() {
		List<User> userList=userRepository.findAll();
		return userList;
		
	}
	@Transactional
	public User saveUser(User user) {
		
		return userRepository.save(user);
		
	}
	@Transactional
	public void updateUser(User user) {
		userRepository.save(user);	
	
	}
	
	@Transactional
	public void deleteUser(int userid) {
		//empRepository.delete(user);	
		System.out.println("service method called");
		userRepository.deleteById(userid);
	
	}
	@Transactional 
	  public User getUser(int id) { 
	  Optional<User> optional= userRepository.findById(id);
	  User user=optional.get();
	  return user; 
	  

}
	
}
