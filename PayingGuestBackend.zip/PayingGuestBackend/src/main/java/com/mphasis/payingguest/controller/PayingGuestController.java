package com.mphasis.payingguest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.payingguest.exception.ResourceNotFoundException;
import com.mphasis.payingguest.model.PayingGuest;
import com.mphasis.payingguest.service.PayingGuestService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class PayingGuestController {

	@Autowired
	PayingGuestService pgService;

//http://localhost:8080/api/v1/getAllPayingGuests
	@GetMapping("/getAllPayingGuests")
	public List<PayingGuest> getPayingGuests() {
		List<PayingGuest> pgList = pgService.fetchPayingGuests();

		return pgList;

	}

	// http://localhost:8080/api/v1/getPayingGuest/1
	@GetMapping("/getPayingGuest/{pgId}")
	public ResponseEntity<PayingGuest> getPayingGuestById(@PathVariable("pgId") int pgId)
			throws ResourceNotFoundException {
		PayingGuest payingguest = pgService.getPayingGuest(pgId);
		return ResponseEntity.ok().body(payingguest);
	}

	// http://localhost:8080/api/v1/savePayingGuest
	@PostMapping("/savePayingGuest")
	public PayingGuest addPayingGuest(@RequestBody PayingGuest payingguest) {
		payingguest  = pgService.savePayingGuest(payingguest);

		// return new ResponseEntity<>("PayingGuest added successsfully", HttpStatus.OK);
		return payingguest;
	}

	// http://localhost:8080/api/v1/updatePayingGuest/2
	@PutMapping("/updatePayingGuest/{id}")
	public ResponseEntity<PayingGuest> updatePayingGuest(@PathVariable("id") int employeeId,
			@RequestBody PayingGuest payingguestDetails) throws ResourceNotFoundException {
		PayingGuest payingguest = pgService.getPayingGuest(employeeId);

		payingguest.setpgName(payingguestDetails.getpgName());
		payingguest.settypeofpg(payingguestDetails.gettypeofpg());
		payingguest.setrentpermonth(payingguestDetails.getrentpermonth());
		payingguest.setnoofrooms(payingguestDetails.getnoofrooms());
		payingguest.setnoofsharing(payingguestDetails.getnoofsharing());
		payingguest.setaddress(payingguestDetails.getaddress());
		payingguest.setlocation(payingguestDetails.getlocation());
		payingguest.setstatus(payingguestDetails.getstatus());
		
		final PayingGuest updatedPayingGuest = pgService.savePayingGuest(payingguest);
		return ResponseEntity.ok(updatedPayingGuest);
	}

//http://localhost:8080/api/v1/deletePayingGuest/1
	@DeleteMapping(value = "/deletePayingGuest/{pgId}")
	public ResponseEntity<Object> deletePayingGuest(@PathVariable("pgId") int pgId) {

	    pgService.deletePayingGuest(pgId);
		return new ResponseEntity<>("PayingGuest deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deletePayingGuest/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int pgId) throws
	 * ResourceNotFoundException { // PayingGuest payingguest =
	 * pgService.getPayingGuest(pgId);
	 * 
	 * System.out.println("delete method called");
	 * pgService.deletePayingGuest(pgId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}


